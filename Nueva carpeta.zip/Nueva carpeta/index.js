const http = require('http');
const fs = require('fs');
const csvWriter = require('csv-writer').createObjectCsvWriter;
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'usuarios_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

async function executeQuery(sql, values = []) {
  try {
    const connection = await pool.getConnection();
    const [rows] = await connection.execute(sql, values);
    connection.release();
    return rows;
  } catch (error) {
    throw error;
  }
}

async function exportUsersToCSV() {
  const csvWriterInstance = csvWriter({
    path: 'usuarios.csv',
    header: [
      { id: 'id', title: 'id' },
      { id: 'nombres', title: 'nombres' },
      { id: 'apellidos', title: 'apellidos' },
      { id: 'direccion', title: 'direccion' },
      { id: 'correo', title: 'correo' }, 
      { id: 'dni', title: 'dni' },
      { id: 'edad', title: 'edad' },
      { id: 'fecha_creacion', title: 'fecha_creacion' },
      { id: 'telefono', title: 'telefono' }
    ]
  });

  try {
    const result = await executeQuery('SELECT * FROM usuarios');
    await csvWriterInstance.writeRecords(result);
    console.log('Usuarios exportados correctamente.');
  } catch (error) {
    console.error('Error al exportar usuarios:', error);
  }
}

async function importUsersFromCSV() {
  try {
    const csvData = fs.readFileSync('usuarios.csv', 'utf8').split('\n').map(row => row.split(','));
    const headers = csvData.shift();

    const usuarios = csvData.map(row => {
      const usuario = {};
      if (row.length === headers.length) {
        headers.forEach((header, index) => {
          const value = row[index] || ''; 
          usuario[header.trim()] = value.trim();
        });
      }
      return usuario;
    });

    for (const usuario of usuarios) {
      const { correo, ...userData } = usuario; 
      const existingUser = await executeQuery('SELECT * FROM usuarios WHERE correo = ?', [correo]);
      if (existingUser.length === 0) {
        const columns = Object.keys(userData).join(', ');
        const placeholders = Object.values(userData).map(value => '?').join(', ');
        const values = Object.values(userData);
        await executeQuery(`INSERT INTO usuarios (correo, ${columns}) VALUES (?, ${placeholders})`, [correo, ...values]); // Agregar 'correo' a los valores
        console.log(`Usuario importado correctamente: ${correo}`);
      }
    }
    console.log('Todos los usuarios han sido importados correctamente.');
  } catch (error) {
    console.error('Error al importar usuarios:', error);
  }
}

const server = http.createServer((req, res) => {
  if (req.url === '/') {
    fs.readFile('index.html', (err, data) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        return res.end('404 Not Found');
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.write(data);
      return res.end();
    });
  } else if (req.url === '/api/usuarios') {
    executeQuery('SELECT * FROM usuarios')
      .then(result => {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
      })
      .catch(error => {
        console.error('Error al obtener usuarios:', error);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Internal Server Error' }));
      });
  } else if (req.url === '/api/usuarios/export') {
    exportUsersToCSV();
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Exportando usuarios a CSV...');
  } else if (req.url === '/api/usuarios/import') {
    importUsersFromCSV();
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Importando usuarios desde CSV...');
  } else {
    res.writeHead(404, { 'Content-Type': 'text/html' });
    res.end('404 Not Found');
  }
});

server.listen(3001, () => {
  console.log('Servidor ejecutándose en http://localhost:3001/');
});
